#!/usr/bin/env python3
"""Independently validate the downloaded functional-browser evidence, without running browsers."""
from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path

from PIL import Image

ROOT = Path(__file__).resolve().parent
SOURCE = "dbde48e9fd5318ef309bf31ed4b9b7e1596ec7d6"
RUN = 42907891884
VERIFY_JOB = 130158519794
NAMES = ["presentation-pixel", "presentation-normal", "presentation-minecraft",
         "presentation-roblox", "presentation-earth-overhead", "presentation-elevation"]


def read_json(path: Path):
    return json.loads(path.read_text())


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def rgba(path: Path):
    with Image.open(path) as image:
        converted = image.convert("RGBA")
        return converted.size, converted.tobytes()


def main():
    artifact = read_json(ROOT / "screens-artifact.json")
    assert artifact["name"] == "atlas-browser-screens"
    assert artifact["workflow_run"]["id"] == RUN
    assert artifact["workflow_run"]["head_sha"] == SOURCE
    archive = (ROOT / "atlas-browser-screens.zip").read_bytes()
    assert len(archive) == artifact["size_in_bytes"]
    assert "sha256:" + sha256(archive) == artifact["digest"]
    job = read_json(ROOT / "verify-job.json")
    assert job["id"] == VERIFY_JOB and job["run_id"] == RUN
    assert job["status"] == "completed" and job["conclusion"] == "success"
    assert all(step["conclusion"] == "success" for step in job["steps"])

    evidence = ROOT / "evidence"
    direct = read_json(evidence / "gpu-direct/visual.json")
    detached = read_json(evidence / "gpu-transfer/visual.json")
    for report in (direct, detached):
        assert [case["name"] for case in report["cases"]] == NAMES
        assert report["errors"] == []
        assert report["requestedGpuRendering"] is True
        assert report["mode"] == "visual"
    for field in ("browser", "viewport", "deviceScaleFactor", "browserArgs", "harnessSha256", "runtime"):
        assert direct[field] == detached[field], field
    source_tests = read_json(ROOT / "source-tests.json")
    assert source_tests["source_sha"] == SOURCE
    assert direct["harnessSha256"] == source_tests["files"]["tests/browser/performance.cjs"]
    assert direct["requiredCompositorGpu"] is True and direct["forcedDetachedGpu"] is False
    assert detached["forcedDetachedGpu"] is True and detached["requiredCompositorGpu"] is False

    comparisons = []
    all_canvas_pixels = 0
    paths = (evidence / "gpu-direct", evidence / "gpu-transfer")
    for index, name in enumerate(NAMES):
        frames = []
        maps = []
        for directory, report in zip(paths, (direct, detached)):
            case = report["cases"][index]
            # The harness retains the full accessible status line in this field.
            assert "GPU active ·" in case["actualBackend"]
            size, frame = rgba(directory / (name + ".png"))
            map_size, image = rgba(directory / (name + ".map.png"))
            assert sha256(frame) == case["canvasHash"]
            assert sha256(image) == case["mapHash"]
            crop = case["crop"]
            with Image.open(directory / (name + ".png")) as opened:
                extracted = opened.convert("RGBA").crop((crop["x"], crop["y"],
                    crop["x"] + crop["width"], crop["y"] + crop["height"]))
                assert extracted.size == map_size and extracted.tobytes() == image
            frames.append((size, frame))
            maps.append((map_size, image))
            gpu = case["gpuEvidence"]
            assert gpu["mapResolves"]
            assert any(count > 0 for count in gpu["artSizedDepthTestedDrawsByPixelSize"].values())
            if directory.name == "gpu-direct":
                assert all(resolve["compositorContext"] for resolve in gpu["mapResolves"])
                assert gpu["readbacks"] == []
            else:
                assert all(not resolve["compositorContext"] for resolve in gpu["mapResolves"])
                assert any(read["mode"] == "pixelPack" for read in gpu["readbacks"])
        assert maps[0] == maps[1], name + " map pixels differ"
        assert frames[0] == frames[1], name + " full-canvas pixels differ"
        all_canvas_pixels += frames[0][0][0] * frames[0][0][1]
        comparisons.append({"name": name, "differentMapPixels": 0,
            "totalMapPixels": maps[0][0][0] * maps[0][0][1], "maxChannelDelta": 0,
            "exactCanvas": True})
    assert comparisons == read_json(evidence / "gpu-direct/comparison.json")

    log = (ROOT / "verify-job.log").read_text()
    expected_counts = {
        "Trusted browser input checks passed for wheel/pinch routing, pointer capture, key repeat and native editing.": 1,
        "Browser checks passed: seeded geometry, Earth imagery in isometric and overhead views, drag, wheel, coordinate search, camera deep link, night lighting, phone viewport and touch pinch.": 2,
        "Passed journey scenario drive": 2,
        "Passed journey scenario groundModes": 2,
        "Passed journey scenario planVia": 2,
        "Passed journey scenario phoneRide": 2,
        "Terrain browser checks passed for real Garda relief, flat comparison, elevation, Map and Earth layers, 2D/3D, picking, orbit, drag, exaggeration, v4 sharing and phone controls.": 2,
        "DPR2 dense-city NorthUp→ground-clamped Orbit, horizon changes and runtime recovery passed.": 1,
        "All four rendering styles and CPU/GPU switching passed.": 1,
        "Desktop trackpad and WebKit gesture routing passed.": 1,
        "Walking, terrain contact and held-jump behavior passed.": 1,
        "Native drag, browser Pointer Lock, relative look and pause passed.": 1,
        "Car driving and all five camera rigs passed.": 1,
        "Held-touch flights, mixed trackpad takeover, camera reattachment and pinch cancellation passed.": 1,
        "Walking, driving, aircraft, free flight and camera controls passed.": 1,
        "Exploration checks passed for GPU defaults, four styles, native gestures, free movement, physical cameras, terrain and mobile controls.": 1,
    }
    for marker, expected in expected_counts.items():
        assert log.count(marker) == expected, (marker, log.count(marker), expected)
    assert not re.search(r"AssertionError|##\[error\]|Unhandled (?:managed )?exception", log)
    failure_artifacts = [str(path.relative_to(evidence)) for path in evidence.rglob("*")
                         if path.is_file() and "failure" in path.name.lower()]
    assert not failure_artifacts, failure_artifacts
    close = read_json(evidence / "explore/high-dpi-close-camera.json")
    assert close["failures"] == [] and len(close["checkpoints"]) == 9
    assert close["geometry"] == {"width": 1800, "height": 924, "ratio": 2,
                                  "canvasWidth": 3600, "canvasHeight": 1848}
    assert close["checkpoints"][-1]["name"] == "returned-to-map"

    files = {str(path.relative_to(ROOT)): {"sha256": sha256(path.read_bytes()), "bytes": path.stat().st_size}
             for path in sorted(evidence.rglob("*")) if path.is_file()}
    summary = {
        "source_sha": SOURCE, "run_id": RUN, "verify_job_id": VERIFY_JOB,
        "verify_conclusion": job["conclusion"],
        "artifact": {"id": artifact["id"], "name": artifact["name"],
                     "sha256": sha256(archive), "bytes": len(archive), "api_digest_verified": True},
        "browser": direct["browser"], "viewport": direct["viewport"],
        "deviceScaleFactor": direct["deviceScaleFactor"], "runtime": direct["runtime"],
        "source_tests": source_tests,
        "presentation": {"cases": comparisons,
                         "total_map_pixels": sum(case["totalMapPixels"] for case in comparisons),
                         "total_full_canvas_pixels": all_canvas_pixels,
                         "image_hashes_recomputed": True, "saved_map_crops_verified": True,
                         "direct_compositor_with_zero_readbacks": True,
                         "detached_with_async_pixel_pack": True},
        "log_markers": expected_counts, "failure_artifacts": failure_artifacts,
        "close_camera": {"checkpoints": [item["name"] for item in close["checkpoints"]],
                         "geometry": close["geometry"], "failures": close["failures"]},
        "file_count": len(files), "files": files,
        "scope": "Independent offline audit of exact downloaded functional validation artifacts; no browser or benchmark rerun."
    }
    (ROOT / "audit.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps({key: summary[key] for key in
                     ("source_sha", "run_id", "verify_job_id", "artifact", "browser", "presentation", "close_camera", "file_count")}, indent=2))


if __name__ == "__main__":
    main()
