#!/usr/bin/env python3
"""Link the browser reports to the independently digest-checked Pages package."""
import base64
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
artifact = json.loads((root / "pages-artifact.json").read_text())
assert artifact["id"] == 13807570605 and artifact["workflow_run"]["id"] == 42907891884
assert artifact["workflow_run"]["head_sha"] == "dbde48e9fd5318ef309bf31ed4b9b7e1596ec7d6"
archive = root / "github-pages.zip"
archive_digest = hashlib.file_digest(archive.open("rb"), "sha256").hexdigest()
assert archive.stat().st_size == artifact["size_in_bytes"]
assert "sha256:" + archive_digest == artifact["digest"]
report = json.loads((root / "evidence/gpu-direct/visual.json").read_text())
runtime = report["runtime"]
site = root / "site/UnoPixelMap"
configs = list(site.glob("package_*/uno-config.js"))
assert len(configs) == 1
expected = {
    str(configs[0].relative_to(site)): runtime["bootstrapConfigSha256"],
    "_framework/" + runtime["loaderName"]: runtime["loaderSha256"],
}
for entry in runtime["nativeWasm"] + runtime["assemblies"]:
    expected["_framework/" + entry["name"]] = base64.b64decode(entry["hash"].removeprefix("sha256-")).hex()
for relative, digest in expected.items():
    with (site / relative).open("rb") as stream:
        assert hashlib.file_digest(stream, "sha256").hexdigest() == digest, relative
result = {
    "source_sha": artifact["workflow_run"]["head_sha"], "run_id": artifact["workflow_run"]["id"],
    "pages_artifact_id": artifact["id"], "pages_archive_sha256": archive_digest,
    "pages_archive_bytes": archive.stat().st_size, "api_digest_verified": True,
    "package": configs[0].parent.name, "runtime_mode": runtime["mode"],
    "matched_report_resource_count": len(expected), "matched_report_resources": expected,
    "scope": "Both functional visual reports have identical runtime metadata. Their recorded bootstrap, loader, native WASM and relevant assembly hashes match the extracted, digest-verified Pages artifact."
}
(root / "package-linkage.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({key: value for key, value in result.items() if key != "matched_report_resources"}, indent=2))
